# Preface

This tool aims to simplify the operations of TAC tech-support analysis by right-click the tech-support file.

It will save the analysis result as a file `tech-support-analysis-result.html` and open it via your default web browser automatically.

> The file "tech-support-analysis-result.html" is located in the folder where the tech-support file is.

# How to install

1. Download the files

   - rightclick-techsupport.exe
   - tech-support-analysis.reg

2. Save the file `rightclick-techsupport.exe` to your local drive. For example:  `W:\Codes\rightclick-techsupport.exe`

3. Edit the `tech-support-analysis.reg` and change the path in the following two lines.

   > Pay attention to the double '\\\\'

``` shell
"icon"="W:\\Codes\\rightclick-techsupport.exe"

@="\"W:\\Codes\\rightclick-techsupport.exe\" \"%1\""
```

4. Save `tech-support-analysis.reg` after editing.
5. Run `tech-support-analysis.reg` with `administrator `

